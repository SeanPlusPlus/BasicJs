Lake.js
=======

Makes cool ass lakes.

No license, do what you want as long as it involves some Cool Ass Lakes.